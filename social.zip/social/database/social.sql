-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 19, 2023 at 09:14 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `disu`
--

-- --------------------------------------------------------

--
-- Table structure for table `chatmsg`
--

CREATE TABLE `chatmsg` (
  `id` int(11) NOT NULL,
  `myid` int(11) NOT NULL,
  `toid` int(11) NOT NULL,
  `msgs` varchar(2000) NOT NULL,
  `msgstatus` varchar(10) NOT NULL,
  `thedate` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `chatmsg`
--

INSERT INTO `chatmsg` (`id`, `myid`, `toid`, `msgs`, `msgstatus`, `thedate`) VALUES
(2, 16, 17, 'fgf', 'R', '13-06-2023 15:40:23'),
(3, 16, 17, 'ds', 'R', '13-06-2023 15:45:36'),
(4, 16, 17, 'sd', 'R', '13-06-2023 15:45:39'),
(5, 16, 17, 'd', 'R', '13-06-2023 15:48:59'),
(6, 16, 17, 'd', 'R', '13-06-2023 15:49:04'),
(7, 16, 17, 'dd', 'R', '13-06-2023 15:52:50'),
(8, 16, 17, 'dfd', 'R', '13-06-2023 16:43:07'),
(9, 17, 16, 'ssd', 'R', '13-06-2023 16:43:15'),
(10, 16, 17, 'ff', 'R', '13-06-2023 16:43:38'),
(11, 17, 16, 'xdfd', 'R', '13-06-2023 16:43:43'),
(12, 17, 16, 'erer', 'R', '13-06-2023 16:43:57'),
(13, 16, 17, 'vcvc', 'R', '13-06-2023 16:44:02'),
(14, 16, 0, 'dfdf', 'UR', '13-06-2023 16:47:36'),
(15, 16, 0, 'ddd', 'UR', '13-06-2023 16:47:45'),
(16, 17, 16, 'dfd', 'R', '13-06-2023 16:50:16'),
(17, 17, 16, 'ss', 'R', '13-06-2023 16:50:19'),
(18, 16, 0, 'dddddddf', 'UR', '13-06-2023 16:50:30'),
(19, 16, 17, 'sd', 'R', '13-06-2023 16:50:43'),
(20, 16, 17, 'js', 'R', '13-06-2023 16:50:49'),
(21, 16, 17, 'sd', 'R', '13-06-2023 16:50:53'),
(22, 16, 17, 'sddfds', 'R', '13-06-2023 16:53:56'),
(23, 16, 17, 'df', 'R', '13-06-2023 16:54:49'),
(24, 17, 16, 'jkj', 'R', '13-06-2023 17:00:13'),
(25, 16, 17, 'mbnm', 'R', '13-06-2023 17:00:35'),
(26, 17, 16, 'lkj', 'R', '13-06-2023 17:00:44'),
(27, 16, 17, 'kjj', 'R', '13-06-2023 17:00:52'),
(28, 17, 16, 'lk', 'R', '13-06-2023 17:01:00'),
(29, 17, 16, 'kk', 'R', '13-06-2023 17:27:20'),
(30, 16, 17, 'dd', 'UR', '17-06-2023 16:37:39');

-- --------------------------------------------------------

--
-- Table structure for table `datapost`
--

CREATE TABLE `datapost` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `postext` varchar(3000) NOT NULL,
  `postimage` varchar(100) NOT NULL,
  `deletation` int(11) NOT NULL,
  `thedate` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `datapost`
--

INSERT INTO `datapost` (`id`, `uid`, `postext`, `postimage`, `deletation`, `thedate`) VALUES
(60, 16, 'rtrtr', '', 1, '09-06-2023 15:24:32'),
(61, 16, '  d', '', 0, '09-06-2023 15:28:20'),
(62, 16, 'vv', '', 0, '09-06-2023 15:37:00'),
(63, 16, 'fh', '', 0, '09-06-2023 15:51:32'),
(64, 16, '', '', 0, '09-06-2023 16:36:41'),
(65, 16, '', '', 0, '09-06-2023 16:39:00'),
(66, 16, '', '', 0, '09-06-2023 16:40:24'),
(67, 16, '', '1747330036720834.jpeg', 0, '10-06-2023 15:27:07'),
(68, 16, '', '1530685318317488.jpeg', 0, '10-06-2023 15:36:20'),
(69, 16, 'xc', '', 1, '10-06-2023 15:43:44'),
(70, 16, 'dfdf', '3562543415948208.jpeg', 1, '10-06-2023 15:43:57'),
(71, 16, '', '282161997908085.jpeg', 1, '10-06-2023 15:44:24'),
(72, 16, '', '2645323844425868.jpeg', 0, '10-06-2023 15:49:43'),
(73, 16, '', '5587213591297003.jpeg', 0, '10-06-2023 15:52:43'),
(74, 16, '', '1469901885715019.jpeg', 0, '10-06-2023 15:59:33'),
(75, 16, 'd', '', 1, '10-06-2023 20:06:13'),
(76, 16, 'ddd', '1444564338629686.jpeg', 0, '10-06-2023 21:54:05'),
(77, 16, ',jb', '', 0, '10-06-2023 21:54:28'),
(78, 16, 'c', '', 1, '11-06-2023 15:03:06'),
(79, 16, 'wrere', '1940848712120544.png', 0, '11-06-2023 15:08:05'),
(80, 16, 'ggg', '', 1, '12-06-2023 17:02:47'),
(81, 17, 'dfdf', '', 0, '13-06-2023 17:21:16'),
(82, 17, 'sdsd', '', 0, '13-06-2023 17:22:35');

-- --------------------------------------------------------

--
-- Table structure for table `likepost`
--

CREATE TABLE `likepost` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `postid` int(11) NOT NULL,
  `deletation` int(11) NOT NULL,
  `thedate` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `likepost`
--

INSERT INTO `likepost` (`id`, `uid`, `postid`, `deletation`, `thedate`) VALUES
(47, 16, 79, 1, '12-06-2023 16:53:54'),
(48, 16, 77, 0, '12-06-2023 17:02:16'),
(49, 16, 76, 0, '12-06-2023 17:02:19'),
(50, 16, 75, 0, '12-06-2023 17:02:20'),
(51, 16, 74, 0, '12-06-2023 17:02:23'),
(52, 16, 72, 0, '12-06-2023 17:02:26'),
(53, 16, 80, 0, '12-06-2023 17:02:53'),
(54, 16, 81, 0, '13-06-2023 17:23:44'),
(55, 16, 82, 0, '13-06-2023 17:23:45'),
(56, 17, 81, 0, '13-06-2023 17:24:29'),
(57, 17, 82, 0, '13-06-2023 17:24:30'),
(58, 16, 61, 1, '17-06-2023 17:07:19'),
(59, 16, 61, 0, '17-06-2023 17:08:42'),
(60, 16, 67, 0, '17-06-2023 17:18:55'),
(61, 16, 68, 0, '17-06-2023 17:18:57');

-- --------------------------------------------------------

--
-- Table structure for table `notifcenter`
--

CREATE TABLE `notifcenter` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `rectid` int(11) NOT NULL,
  `postid` int(11) NOT NULL,
  `notiftype` varchar(100) NOT NULL,
  `notifread` int(11) NOT NULL,
  `thedate` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `notifcenter`
--

INSERT INTO `notifcenter` (`id`, `uid`, `rectid`, `postid`, `notiftype`, `notifread`, `thedate`) VALUES
(2, 16, 16, 61, 'plike', 0, '17-06-2023 17:08:42'),
(3, 16, 16, 67, 'plike', 0, '17-06-2023 17:18:55'),
(4, 16, 16, 68, 'plike', 0, '17-06-2023 17:18:57');

-- --------------------------------------------------------

--
-- Table structure for table `sofollow`
--

CREATE TABLE `sofollow` (
  `id` int(11) NOT NULL,
  `myid` int(11) NOT NULL,
  `fid` int(11) NOT NULL,
  `thedate` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sofollow`
--

INSERT INTO `sofollow` (`id`, `myid`, `fid`, `thedate`) VALUES
(10, 16, 17, '13-06-2023 14:54:20'),
(11, 17, 16, '13-06-2023 16:39:57');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `livestatus` varchar(10) NOT NULL,
  `uimg` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `gender`, `livestatus`, `uimg`) VALUES
(16, 'lokesh', 'lokesh317317@gmail.com', '123', 'Male', 'Y', '1182030276382712.jpeg'),
(17, 'Mihir Sharma', 'mi@gmail.com', '123456', 'Male', 'Y', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chatmsg`
--
ALTER TABLE `chatmsg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `datapost`
--
ALTER TABLE `datapost`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `likepost`
--
ALTER TABLE `likepost`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifcenter`
--
ALTER TABLE `notifcenter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sofollow`
--
ALTER TABLE `sofollow`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chatmsg`
--
ALTER TABLE `chatmsg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `datapost`
--
ALTER TABLE `datapost`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT for table `likepost`
--
ALTER TABLE `likepost`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `notifcenter`
--
ALTER TABLE `notifcenter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sofollow`
--
ALTER TABLE `sofollow`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
