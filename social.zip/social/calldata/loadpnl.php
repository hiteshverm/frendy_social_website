<?php 
  include"../tempart/connect.php"; 
 include"../tempart/function.php"; 
if(isset($_SESSION['dssion'])) {
    $getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['dssion']."'");
    $getrowsifo=mysqli_num_rows($getinfo);
    if($getrowsifo>0)
    {
        $getarrinfo=mysqli_fetch_assoc($getinfo);

if(isset($_POST['getpnl']))
{
    ?>
<form id="form"  method="post" enctype="multipart/form-data">
                                <textarea id="mytext" name="mytext" class="form-control" placeholder="Enter something..."></textarea>
                                <div class="text-right mt-2">
                                    
                                   <input type="submit" name="submit" id="but_upload" class="btn btn-success" value="Post">
                                </div>
                            </form>
<script type="text/javascript">
    $(document).ready(function (e) {
 $("#form").on('submit',(function(e) {
            var mytext=$("#mytext").val();
            if(mytext=="")
            {
                return false;
            }else {
                $("#but_upload").html('<span class="spinner-border spinner-border-sm"></span>');
                $("#but_upload").prop("disabled",true);
                 e.preventDefault();
                $.ajax({
         url: "<?php echo $postdata ?>",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   success: function(data)
      {
        if(data==0)
        {

            
        }else {
            $("textarea").val("");
            $("#but_upload").html('Post');
                $("#but_upload").prop("disabled",false);
                
                $("#dtshow").prepend(data);
                $(".delpost").click(function(){
                    var id=$(this).attr("id");
                    $("#alerttop").empty();
                    $("#lodr"+id).empty();
                    $("#lodr"+id).html('<span class="spinner-border spinner-border-sm"></span>');
                    $.ajax({
            url:"<?php echo $senddel; ?>",
            type:"POST",
            data:"idp="+id,
            success:function(msg)
            {
                if(msg==1)
                {
                    $("#alerttop").empty();
                    $("#alerttop").html('<div class="alertmainS">Deleted <i class="fa fa-check-circle ml-2"></i></div>');
                   $(".alertmainS").slideToggle();
                   setTimeout(function() {
                  $(".alertmainS").slideToggle(500);
                }, 3000);
                    $("#dpost"+id).remove();
                }else {

                }
            }
                    });
                });

$('button.likenow').on('click', function(e){ e.preventDefault();
$button = $(this);
if($button.hasClass('liked')){
var lfid=$(this).attr('id');

var comnterid=$("#MinRpUId"+lfid).val();
$('button.likenow').prop('disabled', true);
$("#likcount"+lfid).empty("");
$("#likcount"+lfid).html('<span class="spinner-border spinner-border-sm"></span>');

$.ajax({url:"<?php echo $sentlike; ?>",
type:"POST",data:"lunid="+lfid,success:function(msg){
    
if(msg=='no'){ $('button.likenow').prop('disabled', false); return false;}else{ 
$("#likcount"+lfid).empty("");
$("#likcount"+lfid).html(msg);
$button.removeClass('liked');
$button.addClass('unlike');
$('button.likenow').prop('disabled', false);
}}});} else {
var lfid=$(this).attr('id');

var comnterid2=$("#MinRpUId"+lfid).val();
$('button.likenow').prop('disabled', true);
$("#likcount"+lfid).empty("");
$("#likcount"+lfid).html('<span class="spinner-border spinner-border-sm"></span>');

$.ajax({url:"<?php echo $sentlike; ?>",
type:"POST",data:"lid="+lfid,success:function(msg){ 
    
if(msg=='no'){ $('button.likenow').prop('disabled', false); return false;}else{     
$("#likcount"+lfid).empty("");
$("#likcount"+lfid).html(msg);
$button.removeClass('unlike');
$button.addClass('liked');
$('button.likenow').prop('disabled', false);
}}});}});
        }
      }

   });
            }
        }));
    });
</script>
<?php }
}

}

?>