<?php 
  include"../tempart/connect.php"; 
 include"../tempart/function.php"; 
if(isset($_SESSION['dssion'])) {
    $getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['dssion']."'");
    $getrowsifo=mysqli_num_rows($getinfo);
    if($getrowsifo>0)
    {
        $getarrinfo=mysqli_fetch_assoc($getinfo);
$data=mysqli_query($db,"SELECT * FROM $notifcenter WHERE rectid='".$_SESSION['dssion']."' AND notifread='0'");
 $row=mysqli_num_rows($data);
if ($row>0) {
	echo '<b style="zindex:1;position:relative;" class="badge badge-danger ml-n3 mt-n3 ">'.$row.'</b>';
}
?>
<?php } } ?>

