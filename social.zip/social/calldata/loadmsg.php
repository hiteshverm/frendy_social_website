<?php 
  include"../tempart/connect.php"; 
 include"../tempart/function.php"; 
if(isset($_SESSION['dssion'])) {
    $getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['dssion']."'");
    $getrowsifo=mysqli_num_rows($getinfo);
    if($getrowsifo>0)
    {
        $getarrinfo=mysqli_fetch_assoc($getinfo);
date_default_timezone_set("Asia/Kolkata"); 
$info = getdate();
$dated = $info['mday'];
$monthe = $info['mon'];
$year = $info['year'];
$hour = $info['hours'];
$min = $info['minutes'];
$sec = $info['seconds'];
if($monthe<10)
{
    $month='0'.$monthe;
}else {
    $month=$monthe;
}
if($dated<10)
{
    $date='0'.$dated;
}else 
{
    $date=$dated;
}
if($hour<10){
    $hourr='0'.$hour;
}else {
    $hourr=$hour;
}
if($min<10){
    $minn='0'.$min;
}else {
    $minn=$min;
}
if($sec<10){
    $secc='0'.$sec;
}else {
    $secc=$sec;
}
$thedate=$date.'-'.$month.'-'.$year.' '.$hourr.':'.$minn.':'.$secc;

if(isset($_POST['userid'])){
	$userid=$_POST['userid'];
	$chat=mysqli_query($db,"SELECT * FROM $chatmsg WHERE myid='".$_SESSION['dssion']."' AND toid='$userid' OR toid='".$_SESSION['dssion']."' AND myid='$userid' limit 60");
	while($fetch=mysqli_fetch_array($chat)){
	?>
	<?php
	if(($fetch['myid']==$userid)&&($fetch['toid']==$_SESSION['dssion'])){
		echo'<div class="d-flex justify-content-start mt-3"><div class="challist">'.$fetch['msgs'].'</div></div>';
	}
	if(($fetch['myid']==$_SESSION['dssion'])&&($fetch['toid']==$userid)){
		echo'<div class="d-flex justify-content-end mt-3"><div class="challist2">'.$fetch['msgs'].'</div></div>';
	}
	?>
<?php
	}

}
?>

<?php } } ?>