<?php 
  include"../tempart/connect.php"; 
 include"../tempart/function.php"; 
if(isset($_SESSION['dssion'])) {
    $getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['dssion']."'");
    $getrowsifo=mysqli_num_rows($getinfo);
    if($getrowsifo>0)
    {
        $getarrinfo=mysqli_fetch_assoc($getinfo);


	$dataroww='';

$dataw=mysqli_query($db,"SELECT * FROM $utable WHERE livestatus='Y' ");
 $row2w=mysqli_num_rows($dataw);
 if($row2w>0)
 {
while($datarrayw=mysqli_fetch_array($dataw))
{	$ttt=$datarrayw['id'];
if($_SESSION['dssion']!=$ttt)
{
	$getdataw=mysqli_query($db,"SELECT * FROM $sofollow WHERE myid='".$_SESSION['dssion']."' and fid='$ttt' order by id desc");

$dataroww=mysqli_num_rows($getdataw);
}
}
if($dataroww>0)
{
echo '<small class="spinner-grow spinner-grow-sm text-light "></small><b class="badge badge-danger ">'.$dataroww.'</b>';
}
}
}
}


?>