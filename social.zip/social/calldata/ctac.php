<?php

include"../tempart/connect.php";
include"../tempart/function.php"; 
if(isset($_POST['name']))
{
$name=mysqli_escape_string($db,$_POST['name']);
$pass=mysqli_escape_string($db,$_POST['npassword']);
$email=mysqli_escape_string($db,$_POST['email']);
$gender=mysqli_escape_string($db,$_POST['gender']);

$checkdata=mysqli_query($db,"SELECT * FROM $utable where email='$email'");
$checkrow=mysqli_num_rows($checkdata);
if($checkrow==0){


$insertdata=mysqli_query($db,"INSERT INTO $utable set name='$name',email='$email',password='$pass',gender='$gender'");
if($insertdata)
{
$getdata=mysqli_query($db,"SELECT * FROM $utable where email='$email'");
$getrow=mysqli_num_rows($getdata);
if($getrow!=0){


	$array=mysqli_fetch_array($getdata);
	function random_strings($length_of_string) 
{$str_result = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnopqrstuvwxyz'; 
return substr(str_shuffle($str_result), 0, $length_of_string); 
}
 $key=random_strings($array['id']);
 $upddas=mysqli_query($db,"UPDATE $utable set fistverify='$key' WHERE id='".$array['id']."'");


			// $_SESSION['dssion']=$array['id'];
			// $_SESSION['myname']=$array['name'];
			
	echo $array['id'];
}else{
	echo 0;
}
}else {
	echo 0;
}
}else{
	echo 0;
}
}
 ?>

