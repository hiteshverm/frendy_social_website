<?php 
  include"../tempart/connect.php"; 
 include"../tempart/function.php"; 
if(isset($_SESSION['dssion'])) {
    $getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['dssion']."'");
    $getrowsifo=mysqli_num_rows($getinfo);
    if($getrowsifo>0)
    {
        $getarrinfo=mysqli_fetch_assoc($getinfo);
if(isset($_POST['id']))
{
$uid=$_POST['id'];
$gerconfi=mysqli_query($db,"SELECT * FROM $chatmsg WHERE toid='".$_SESSION['dssion']."' AND msgstatus='UR'");
$getrowsd=mysqli_num_rows($gerconfi);
if($getrowsd>0)
{
	$data=mysqli_query($db,"UPDATE  $chatmsg SET msgstatus='R' WHERE  toid='".$_SESSION['dssion']."' AND msgstatus='UR'");
 
if($data) {
	echo 1;
}
}

?>
<?php } } } ?>

