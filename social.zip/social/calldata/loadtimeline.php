<?php 
  include"../tempart/connect.php"; 
 include"../tempart/function.php"; 
if(isset($_SESSION['dssion'])) {
    $getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['dssion']."'");
    $getrowsifo=mysqli_num_rows($getinfo);
    if($getrowsifo>0)
    {
        $getarrinfo=mysqli_fetch_assoc($getinfo);
date_default_timezone_set("Asia/Kolkata"); 
$info = getdate();
$dated = $info['mday'];
$monthe = $info['mon'];
$year = $info['year'];
$hour = $info['hours'];
$min = $info['minutes'];
$sec = $info['seconds'];
if($monthe<10)
{
    $month='0'.$monthe;
}else {
    $month=$monthe;
}
if($dated<10)
{
    $date='0'.$dated;
}else 
{
    $date=$dated;
}
if($hour<10){
    $hourr='0'.$hour;
}else {
    $hourr=$hour;
}
if($min<10){
    $minn='0'.$min;
}else {
    $minn=$min;
}
if($sec<10){
    $secc='0'.$sec;
}else {
    $secc=$sec;
}
$thedate=$date.'-'.$month.'-'.$year.' '.$hourr.':'.$minn.':'.$secc;

if(isset($_POST["limit"], $_POST["start"], $_POST["pid"]))
{
	if(($_POST["limit"]=="")&&($_POST["start"]=="")&&($_POST["pid"]==""))
		{
			exit();
		}else
	{
        $pidr=$_POST["pid"];
 $queryJ = mysqli_query($db,"SELECT * FROM $dataposttbl WHERE uid='$pidr' and deletation='0' ORDER BY id DESC LIMIT ".$_POST["start"].", ".$_POST["limit"]." ");
 $chnlTagrowJ=mysqli_num_rows($queryJ);
				if($chnlTagrowJ>0)
				{
						
 while($chnlTagFchJ = mysqli_fetch_assoc($queryJ))
 { 					


 										$pid=$chnlTagFchJ['id'];
 										$cheku=mysqli_query($db,"SELECT * FROM $utable WHERE id='$pidr'");
 										$getrowU=mysqli_fetch_assoc($cheku);

                    $postlike=mysqli_query($db,"SELECT * FROM $likepost WHERE uid='".$_SESSION['dssion']."' AND postid='".$chnlTagFchJ['id']."' AND deletation='0'");
                    $postlkrow=mysqli_num_rows($postlike);
      ?><div id="dpost<?php echo $chnlTagFchJ['id']; ?>" class="col-md-12  mt-4">
 					<div class="card  ">
            <div class="media px-2 py-2 ">
                <?php if($getrowU['uimg']!=""){ $imgname='<a href="'.$profilelink.''.$getrowU['id'].'"><img class="rounded-circle mr-2" width="39" height="39" src="'.$proilelink.$getrowU['uimg'].'"></a>'; }else { $imgname='<a href="'.$profilelink.''.$getrowU['id'].'"><img width="39" height="39" src="'.$imglinks.'"></a>'; } ?>
            <?php echo $imgname; ?>
            <div class="media-body ">
                <h6 class="pl-2 pb-0 mb-0 text-capitalize"><a class="text-dark" href="<?php echo $profilelink.$getrowU['id']; ?>"><?php echo $getrowU['name']; ?></a></h6>
                <div class="pl-2"><small style="font-size:12px;" class="text-muted "><?php echo time_ago_in_php($chnlTagFchJ['thedate']); ?></small></div>
            </div>
            <div id="lodr<?php echo $chnlTagFchJ['id']; ?>" class="dropdown dropleft">
            <i data-toggle="dropdown" class="fa fa-ellipsis-v" aria-hidden="true"></i>
            <div class="dropdown-menu shadow">
                <?php if($pidr==$_SESSION['dssion']) { ?>
                    <a id="<?php echo $chnlTagFchJ['id']; ?>" class="dropdown-item delpost" href="#">Delete</a>
                <?php } ?>
                    <a class="dropdown-item" href="#">Report</a>
                    
                </div>
            </div>
        </div>
        <?php if($chnlTagFchJ['postimage']!=""){ echo '<img class="newsfeedimg" src='.$postlink.$chnlTagFchJ['postimage'].'>'; } ?>
            <div class="card-body pt-0">
                <?php echo $chnlTagFchJ['postext']; ?>
            </div>
            <div class="likcommnt">

                <?php if($postlkrow==0)
        { 
        echo '<button  id="'.$chnlTagFchJ['id'].'" class="likenow shadow unlike"><i  class="fa fa-heart   fa-2x"></i></button>';
        }else
        { 
            echo '<button  id="'.$chnlTagFchJ['id'].'" class="likenow shadow liked"><i  class="fa fa-heart fa-2x"></i></button>';
        } ?>
        <span class="ml-n2 mt-n3 badge shadow badge-light badge-pill" id="likcount<?php echo $chnlTagFchJ['id']; ?>"><?php echo custom_number_format(getLikeDB($db,$pid,$likepost)); ?></span>
            </div>
        </div>
	</div>

<?php } 
}else
{
	exit();
}
}?>
<script type="text/javascript">
	$('button.likenow').on('click', function(e){ e.preventDefault();
$button = $(this);
if($button.hasClass('liked')){
var lfid=$(this).attr('id');

var comnterid=$("#MinRpUId"+lfid).val();
$('button.likenow').prop('disabled', true);
$("#likcount"+lfid).empty("");
$("#likcount"+lfid).html('<span class="spinner-border spinner-border-sm"></span>');

$.ajax({url:"<?php echo $sentlike; ?>",
type:"POST",data:"lunid="+lfid,success:function(msg){
    
if(msg=='no'){ $('button.likenow').prop('disabled', false); return false;}else{ 
$("#likcount"+lfid).empty("");
$("#likcount"+lfid).html(msg);
$button.removeClass('liked');
$button.addClass('unlike');
$('button.likenow').prop('disabled', false);
}}});} else {
var lfid=$(this).attr('id');

var comnterid2=$("#MinRpUId"+lfid).val();
$('button.likenow').prop('disabled', true);
$("#likcount"+lfid).empty("");
$("#likcount"+lfid).html('<span class="spinner-border spinner-border-sm"></span>');

$.ajax({url:"<?php echo $sentlike; ?>",
type:"POST",data:"lid="+lfid,success:function(msg){ 
    
if(msg=='no'){ $('button.likenow').prop('disabled', false); return false;}else{     
$("#likcount"+lfid).empty("");
$("#likcount"+lfid).html(msg);
$button.removeClass('unlike');
$button.addClass('liked');
$('button.likenow').prop('disabled', false);
}}});}});
</script>
<?php 
}
else
{
	exit();
}

}
}
?>