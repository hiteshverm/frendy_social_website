<?php 
  include"../tempart/connect.php"; 
 include"../tempart/function.php"; 
if(isset($_SESSION['dssion'])) {
    $getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['dssion']."'");
    $getrowsifo=mysqli_num_rows($getinfo);
    if($getrowsifo>0)
    {
        $getarrinfo=mysqli_fetch_assoc($getinfo);
							$getdata=mysqli_query($db,"SELECT * FROM $sofollow WHERE myid='".$_SESSION['dssion']."' order by id desc");
							$datarow=mysqli_num_rows($getdata);
							if ($datarow!=0) {
								
							while ($dataarray=mysqli_fetch_array($getdata)) {
							$followid=$dataarray['fid'];
							$data=mysqli_query($db,"SELECT * FROM $utable WHERE id='$followid'order by id desc");
							$row2=mysqli_num_rows($data);
							if ($row2!=0) {
							$datarray=mysqli_fetch_array($data);

							if($datarray['uimg']!=""){ $imgnamee='<img  class="rounded-circle mr-2" width="39" height="39" src="'.$proilelink.$datarray['uimg'].'">'; }else { $imgnamee='<img width="39" height="39" src="'.$imglinks.'">'; }	
					      if($datarray['id']!=$_SESSION['dssion'])
					      {
					      
					          $DED=$datarray['id'];
						?>
						<a class="ulist text-white" href="<?php echo $chatlink; ?><?php echo  $datarray['id']; ?>" id="<?php echo  $datarray['id']; ?>">
							<div class="media listborder mt-2">
								
							<?php echo $imgnamee; ?>

							<div class="media-body">
								<p class="mt-2 pb-0 mb-0 text-dark"><?php if($datarray['livestatus']=='Y') {
								echo '<i class="fa fa-circle text-success mr-1"></i>';
								} ?><?php echo $datarray['name']; ?></p>
								<?php
								
								$dataGG=mysqli_query($db,"SELECT * FROM $chatmsg WHERE toid='".$_SESSION['dssion']."' AND myid='$DED' AND msgstatus='UR'");
 $rowEE=mysqli_num_rows($dataGG);
if ($rowEE>0) {
	echo '<b class="badge badge-success ml-2 ">'.$rowEE.'</b>';
}
								?>
								
							</div>
						</div></a><?php }   }}}
						else{
							echo 'no users found';
						}
						?>
						
<?php 

}
}
?>
