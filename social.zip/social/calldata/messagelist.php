<?php 
  include"../tempart/connect.php"; 
 include"../tempart/function.php"; 
if(isset($_SESSION['dssion'])) {
    $getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['dssion']."'");
    $getrowsifo=mysqli_num_rows($getinfo);
    if($getrowsifo>0)
    {
        $getarrinfo=mysqli_fetch_assoc($getinfo);
        if(isset($_POST['id']))
        {
							$getdatat=mysqli_query($db,"SELECT * FROM $sofollow WHERE myid='".$_SESSION['dssion']."' order by id desc");
							$datarowt=mysqli_num_rows($getdatat);
							if ($datarowt!=0) {
								
							while ($dataarrayt=mysqli_fetch_array($getdatat)) {
							$followidt=$dataarrayt['fid'];
							$datat=mysqli_query($db,"SELECT * FROM $utable WHERE id='$followidt'order by id desc");
							$row2t=mysqli_num_rows($datat);
							if ($row2t!=0) {
							$datarrayt=mysqli_fetch_array($datat);

							if($datarrayt['uimg']!=""){ $imgnamee='<img  class="rounded-circle mr-2" width="39" height="39" src="'.$proilelink.$datarrayt['uimg'].'">'; }else { $imgnamee='<img width="39" height="39" src="'.$imglinks.'">'; }	
					      if($datarrayt['id']!=$_SESSION['dssion'])
					      {
					      
					          $DEDt=$datarrayt['id'];
						?>
						<a class="ulist text-white dropdown-item" href="<?php echo $chatlink; ?><?php echo  $datarrayt['id']; ?>" id="<?php echo  $datarrayt['id']; ?>">
							<div class="media listborder mt-2">
								
							<?php echo $imgnamee; ?>

							<div class="media-body">
								<p class="mt-2 pb-0 mb-0 text-dark"><?php if($datarrayt['livestatus']=='Y') {
								echo '<i class="fa fa-circle text-success mr-1"></i>';
								} ?><?php echo $datarrayt['name']; ?></p>
								
								
							</div>
							<?php
								
								$dataGGr=mysqli_query($db,"SELECT * FROM $chatmsg WHERE toid='".$_SESSION['dssion']."' AND myid='$DEDt' AND msgstatus='UR'");
 $rowEEe=mysqli_num_rows($dataGGr);
if ($rowEEe>0) {
	echo '<b class="badge badge-success mt-2">'.$rowEEe.'</b>';
}
								?>
						</div></a><?php }   }}}
						else{
							echo 'no users found';
						}
						?>
						
<?php 
}
}
}
?>
