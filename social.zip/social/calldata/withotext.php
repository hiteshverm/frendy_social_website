<?php 
  include"../tempart/connect.php"; 
 include"../tempart/function.php"; 
if(isset($_SESSION['dssion'])) {
    $getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['dssion']."'");
    $getrowsifo=mysqli_num_rows($getinfo);
    if($getrowsifo>0)
    {
        $getarrinfo=mysqli_fetch_assoc($getinfo);
date_default_timezone_set("Asia/Kolkata"); 
$info = getdate();
$dated = $info['mday'];
$monthe = $info['mon'];
$year = $info['year'];
$hour = $info['hours'];
$min = $info['minutes'];
$sec = $info['seconds'];
if($monthe<10)
{
    $month='0'.$monthe;
}else {
    $month=$monthe;
}
if($dated<10)
{
    $date='0'.$dated;
}else 
{
    $date=$dated;
}
if($hour<10){
    $hourr='0'.$hour;
}else {
    $hourr=$hour;
}
if($min<10){
    $minn='0'.$min;
}else {
    $minn=$min;
}
if($sec<10){
    $secc='0'.$sec;
}else {
    $secc=$sec;
}
$thedate=$date.'-'.$month.'-'.$year.' '.$hourr.':'.$minn.':'.$secc;

function compressImage($source, $destination, $quality) { 
    // Get image info 
    $imgInfo = getimagesize($source); 
    $mime = $imgInfo['mime']; 
     
    // Create a new image from file 
    switch($mime){ 
        case 'image/jpeg': 
            $image = imagecreatefromjpeg($source); 
            break; 
        case 'image/png': 
            $image = imagecreatefrompng($source); 
            break; 
        case 'image/gif': 
            $image = imagecreatefromgif($source); 
            break; 
        default: 
            $image = imagecreatefromjpeg($source); 
    } 
     
    // Save image 
    imagejpeg($image, $destination, $quality); 
     
    // Return compressed image 
    return $destination; 
} 
 
 
// File upload path 
$uploadPath = '../assets/media/postimg/'; 
 
// If file upload form is submitted 
$status = $statusMsg = ''; 
$min_rand=rand(0,1000);
$max_rand=rand(100000000000,10000000000000000);
$name_file=rand($min_rand,$max_rand);//this part is for creating random name for image


$parts = explode('.', $_FILES["image"]["name"]);
$file_extension = end($parts);
$nname=$name_file.".".$file_extension;
    $status = 'error'; 
    if(!empty($_FILES["image"]["name"])) { 
        // File info 
        
        $imageUploadPath = $uploadPath . $nname; 
        $fileType = pathinfo($imageUploadPath, PATHINFO_EXTENSION); 
         
        // Allow certain file formats 
        $allowTypes = array('jpg','png','jpeg','gif'); 
        if(in_array($fileType, $allowTypes)){ 
            // Image temp source 
            $imageTemp = $_FILES["image"]["tmp_name"]; 
             
            // Compress size and upload image 
            $compressedImage = compressImage($imageTemp, $imageUploadPath, 50); 
             
            if($compressedImage){ 
                 
                 
                 
                $insertimg=mysqli_query($db,"INSERT INTO $dataposttbl set postimage='$nname', uid='".$_SESSION['dssion']."',thedate='$thedate'");
                if($insertimg)
                {
                     $getPost=mysqli_query($db,"SELECT * FROM $dataposttbl WHERE uid='".$_SESSION['dssion']."' and deletation='0' order by id desc limit 1");
            $joipost=mysqli_num_rows($getPost);
            if($joipost!=0)
            {
                $joinarry=mysqli_fetch_assoc($getPost);
                {
                    $pid=$joinarry['id'];
                    $postlike=mysqli_query($db,"SELECT * FROM $likepost WHERE uid='".$_SESSION['dssion']."' AND postid='".$joinarry['id']."' AND deletation='0'");
                    $postlkrow=mysqli_num_rows($postlike); ?>
                    <div id="dpost<?php echo $joinarry['id']; ?>" class="card  mt-4">
            <div class="media px-2 py-2 ">
                <?php if($getarrinfo['uimg']!=""){ $imgname='<img class="rounded-circle mr-2" width="39" height="39" src="'.$proilelink.$getarrinfo['uimg'].'">'; }else { $imgname='<a href=""><i class="fa fa-user-circle fa-2x mr-2 txtcolor"></i></a>'; } ?>
            <?php echo $imgname; ?>
            <div class="media-body ">
                <h6 class="pl-2 pb-0 mb-0 text-capitalize"><?php echo $getarrinfo['name']; ?></h6>
                <div class="pl-2"><small style="font-size:12px;" class="text-muted"><?php echo time_ago_in_php($joinarry['thedate']); ?></small></div>
            </div>
            <div id="lodr<?php echo $joinarry['id']; ?>" class="dropdown dropleft">
            <i data-toggle="dropdown" class="fa fa-ellipsis-v" aria-hidden="true"></i>
            <div class="dropdown-menu shadow">
                    <a id="<?php echo $joinarry['id']; ?>" class="dropdown-item delpost" href="#">Delete</a>
                    <a class="dropdown-item" href="#">Report</a>
                    
                </div>
            </div>
        </div>
        <?php if($joinarry['postimage']==""){ echo '<img class="newsfeedimg" src='.$postlink.$joinarry['postimage'].'>'; } ?>
        
            <div class="card-body pt-0">
                <?php echo $joinarry['postext']; ?>
            </div>
            <div class="likcommnt">

                <?php if($postlkrow==0)
        { 
        echo '<button  id="'.$joinarry['id'].'" class="likenow shadow unlike"><i  class="fa fa-heart   fa-2x"></i></button>';
        }else
        { 
            echo '<button  id="'.$joinarry['id'].'" class="likenow shadow liked"><i  class="fa fa-heart fa-2x"></i></button>';
        } ?>
        <span class="ml-n2 mt-n3 badge shadow badge-light badge-pill" id="likcount<?php echo $joinarry['id']; ?>"><?php echo custom_number_format(getLikeDB($db,$pid,$likepost)); ?></span>
            </div>
        </div>

                    <?php
                } }
                }else {
                   echo 0; 

                }
            }else{ 
                echo 0; 
            } 
        }else{ 
            echo 0; 
        } 
    }else{ 
        echo 0; 
    } 

 
// Display status message 
echo $statusMsg; 
 }

}
?>