<?php 
  include"../tempart/connect.php"; 
 include"../tempart/function.php"; 
if(isset($_SESSION['dssion'])) {
    $getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['dssion']."'");
    $getrowsifo=mysqli_num_rows($getinfo);
    if($getrowsifo>0)
    {
        $getarrinfo=mysqli_fetch_assoc($getinfo);

    if(isset($_POST['search']))
    {
        $search=$_POST['search'];
        $queryJd = mysqli_query($db,"SELECT * FROM $utable WHERE  name like '%$search%'  ORDER BY id DESC LIMIT 10 ");
 $chnlTagrowJd=mysqli_num_rows($queryJd);
 
                if($chnlTagrowJd>0)
                {
             echo '<ul class="list-group">';           
 while($chnlTagFchJd = mysqli_fetch_assoc($queryJd))
 {
if($chnlTagFchJd['uimg']!=""){ $imgname='<img  class="rounded-circle mr-2" width="39" height="39" src="'.$proilelink.$chnlTagFchJd['uimg'].'">'; }else { $imgname='<img width="39" height="39" src="'.$imglinks.'">'; }
  ?>

<li class="list-group-item">
    <a href="<?php echo $profilelink.$chnlTagFchJd['id']; ?>" class="text-dark">
                                
        <div class="media">
            <?php echo $imgname; ?>
            <div class="media-body">
                <p class="mt-2"><?php echo $chnlTagFchJd['name']; ?></p>
            </div>
        </div>
    </a>
</li>

 <?php }
echo '<li class="list-group-item text-center"><a class="text-info" href="'.$searchlink.''.$search.'">View All</a></li></ul>';
}else {
echo '<ul class="list-group"><li class="list-group-item">No data found</li> </ul>';  

}

    }  
}


}

?>