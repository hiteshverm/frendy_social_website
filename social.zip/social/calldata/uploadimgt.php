<?php 
  include"../tempart/connect.php"; 
 include"../tempart/function.php"; 
if(isset($_SESSION['dssion'])) {
    $getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['dssion']."'");
    $getrowsifo=mysqli_num_rows($getinfo);
    if($getrowsifo>0)
    {
        $getarrinfo=mysqli_fetch_assoc($getinfo);

function compressImage($source, $destination, $quality) { 
    // Get image info 
    $imgInfo = getimagesize($source); 
    $mime = $imgInfo['mime']; 
     
    // Create a new image from file 
    switch($mime){ 
        case 'image/jpeg': 
            $image = imagecreatefromjpeg($source); 
            break; 
        case 'image/png': 
            $image = imagecreatefrompng($source); 
            break; 
        case 'image/gif': 
            $image = imagecreatefromgif($source); 
            break; 
        default: 
            $image = imagecreatefromjpeg($source); 
    } 
     
    // Save image 
    imagejpeg($image, $destination, $quality); 
     
    // Return compressed image 
    return $destination; 
} 
 
 
// File upload path 
$uploadPath = '../assets/media/profile/'; 
 
// If file upload form is submitted 
$status = $statusMsg = ''; 
$min_rand=rand(0,1000);
$max_rand=rand(100000000000,10000000000000000);
$name_file=rand($min_rand,$max_rand);//this part is for creating random name for image


$parts = explode('.', $_FILES["image"]["name"]);
$file_extension = end($parts);
$nname=$name_file.".".$file_extension;
    $status = 'error'; 
    if(!empty($_FILES["image"]["name"])) { 
        // File info 
        
        $imageUploadPath = $uploadPath . $nname; 
        $fileType = pathinfo($imageUploadPath, PATHINFO_EXTENSION); 
         
        // Allow certain file formats 
        $allowTypes = array('jpg','png','jpeg','gif'); 
        if(in_array($fileType, $allowTypes)){ 
            // Image temp source 
            $imageTemp = $_FILES["image"]["tmp_name"]; 
             
            // Compress size and upload image 
            $compressedImage = compressImage($imageTemp, $imageUploadPath, 50); 
             
            if($compressedImage){ 
                 
                 
                 
                $insertimg=mysqli_query($db,"UPDATE $utable set uimg='$nname' WHERE id='".$_SESSION['dssion']."'");
                if($insertimg)
                {
                     $statusMsg = '<div class="badge badge-success w-100 px-2 py-2 mb-3">Uploaded <i class="fa fa-check-circle mr-2"></i> </div>';
                }else {
                    $statusMsg = '<div class="badge badge-danger w-100 px-2 py-3">Image upload failed!</div>';

                }
            }else{ 
                $statusMsg = '<div class="badge badge-danger w-100 px-2 py-3">Image compress failed!</div>'; 
            } 
        }else{ 
            $statusMsg = '<div class="badge badge-danger w-100 px-2 py-3">Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.</div>'; 
        } 
    }else{ 
        $statusMsg = '<div class="badge badge-danger w-100 px-2 py-3">Please select an image file to upload.</div>'; 
    } 

 
// Display status message 
echo $statusMsg; 
 }

}
?>