<?php 
  include"../tempart/connect.php"; 
 include"../tempart/function.php"; 
if(isset($_SESSION['dssion'])) {
    $getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['dssion']."'");
    $getrowsifo=mysqli_num_rows($getinfo);
    if($getrowsifo>0)
    {
        $getarrinfo=mysqli_fetch_assoc($getinfo);
date_default_timezone_set("Asia/Kolkata"); 
$info = getdate();
$dated = $info['mday'];
$monthe = $info['mon'];
$year = $info['year'];
$hour = $info['hours'];
$min = $info['minutes'];
$sec = $info['seconds'];
if($monthe<10)
{
    $month='0'.$monthe;
}else {
    $month=$monthe;
}
if($dated<10)
{
    $date='0'.$dated;
}else 
{
    $date=$dated;
}
if($hour<10){
    $hourr='0'.$hour;
}else {
    $hourr=$hour;
}
if($min<10){
    $minn='0'.$min;
}else {
    $minn=$min;
}
if($sec<10){
    $secc='0'.$sec;
}else {
    $secc=$sec;
}
$thedate=$date.'-'.$month.'-'.$year.' '.$hourr.':'.$minn.':'.$secc;

if(isset($_POST["limit"], $_POST["start"], $_POST["pid"]))
{
	if(($_POST["limit"]=="")&&($_POST["start"]=="")&&($_POST["pid"]==""))
		{
			exit();
		}else
	{
        $pidr=$_POST["pid"];
 $queryJ = mysqli_query($db,"SELECT * FROM $sofollow WHERE fid='$pidr'  ORDER BY id DESC LIMIT ".$_POST["start"].", ".$_POST["limit"]." ");
 $chnlTagrowJ=mysqli_num_rows($queryJ);
				if($chnlTagrowJ>0)
				{
						
 while($chnlTagFchJ = mysqli_fetch_assoc($queryJ))
 { 
    $getuinf=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$chnlTagFchJ['myid']."'");
    $getarr=mysqli_fetch_assoc($getuinf);
$unfollows=mysqli_query($db,"SELECT * FROM $sofollow WHERE  fid='$pidr' and myid='".$chnlTagFchJ['fid']."' ");
$rowss=mysqli_num_rows($unfollows);
    if($getarr['uimg']!=""){ $imgname='<a href="'.$profilelink.''.$getarr['id'].'"><img  class="rounded-circle mr-2" width="39" height="39" src="'.$proilelink.$getarr['uimg'].'"></a>'; }else { $imgname='<a href="'.$profilelink.''.$getarr['id'].'"><i class="fa fa-user-circle fa-2x mr-2 txtcolor"></i></a>'; }
 ?>	
<div class="col-md-12">
    
                            <div class="media bg-light py-2 w-100 border-bottom">
                                <?php echo $imgname; ?>
                                <div class="media-body">
                                    <div class="d-flex justify-content-between align-items-center">
                                    <a href="<?php echo $profilelink.$getarr['id']; ?>" class="text-dark"><p class="mt-2"><?php echo $getarr['name']; ?></p></a>
                                    <?php if($getarr['id']!=$_SESSION['dssion'])
                                        { 

                                            if($rowss>0){
                                        
                             ?>
                             
                            <button class="followbtnn unfolloww px-3 rounded-pill" id=" <?php echo $getarr['id']; ?>" >following</button>

                            <?php  }else {?>
                                <button class="followbtnn followingg rounded-pill px-3" id=" <?php echo $getarr['id']; ?>" >follow</button>
                            <?php } }  ?>
                            </div>
                                </div>
                            </div>
                        
                </div>  


<?php } 
}else
{
    exit();
}
}?>
<script type="text/javascript">
$(document).ready(function(){   
$('button.followbtnn').on('click', function(e){
e.preventDefault();
$button = $(this);
if($button.hasClass('followingg')){
var fid=$(this).attr('id');

$.ajax({
url:"<?php echo $sentlike; ?>",
type:"POST",
data:"id="+fid,
success:function(msg)

{

if(msg==0){return false;}else{  
$button.removeClass('followingg');
$button.addClass('unfolloww');
$button.text('Followingg');

}}});
}else {var fid=$(this).attr('id');

$.ajax({ url:"<?php echo $sentlike; ?>",
type:"POST",
data:"nid="+fid,
success:function(msg)
{ 
    if(msg==0){return false;}else{  

$button.removeClass('unfolloww');
$button.addClass('followingg');
$button.text('Follow');

} }});}});});
</script>

<?php 
}
else
{
    exit();
}

}
}
?>