<?php 
  include"../tempart/connect.php"; 
 include"../tempart/function.php"; 
if(isset($_SESSION['dssion'])) {
    $getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['dssion']."'");
    $getrowsifo=mysqli_num_rows($getinfo);
    if($getrowsifo>0)
    {
        $getarrinfo=mysqli_fetch_assoc($getinfo);
if(isset($_POST['id']))
{
$uid=$_POST['id'];
$gerconfi=mysqli_query($db,"SELECT * FROM $notifcenter WHERE rectid='".$_SESSION['dssion']."' AND notifread='0'");
$getrowsd=mysqli_num_rows($gerconfi);
if($getrowsd>0)
{
	$data=mysqli_query($db,"UPDATE  $notifcenter SET notifread='1' WHERE  rectid='".$_SESSION['dssion']."' AND notifread='0'");
 
if($data) {
	echo 1;
}
}

?>
<?php } } } ?>

