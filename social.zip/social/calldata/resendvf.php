<?php 
include"../tempart/connect.php";
include"../tempart/function.php";


if(isset($_POST['id']))
{
    $checkid=$_POST['id'];
   if($checkid!="")
   {
    $checkidsql=mysqli_query($db,"SELECT * FROM $utable WHERE id='$checkid'");
    $GTROW=mysqli_num_rows($checkidsql);
    if($GTROW>0)
{
    $getarrfv=mysqli_fetch_assoc($checkidsql);
    $mkey=$getarrfv['fistverify'];
    if($mkey!="")
    {

  $to      = $getarrfv['email'];
    $subject = 'Email verificaton link';
    $message = '<a href="http://www.ciitm.org/app/firstverification.php?key='.$mkey.'">Change Password click here</a>';
    $headers = 'From: webmaster@example.com'       . "\r\n" .
                 'Reply-To: webmaster@example.com' . "\r\n" .
                 'X-Mailer: PHP/' . phpversion();

    $sentiem=mail($to, $subject, $message, $headers);
    if($sentiem)
    {
        echo 1;
    }else {
        echo 0;
    }

}
}
}
else {
    echo 0;
}
}

?>