<?php 
  include"../tempart/connect.php"; 
 include"../tempart/function.php"; 
if(isset($_SESSION['dssion'])) {
    $getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['dssion']."'");
    $getrowsifo=mysqli_num_rows($getinfo);
    if($getrowsifo>0)
    {
        $getarrinfo=mysqli_fetch_assoc($getinfo);

$getnotifct=mysqli_query($db,"SELECT * FROM $notifcenter where rectid='".$_SESSION['dssion']."' order by id desc limit  10");
$getNrow=mysqli_num_rows($getnotifct);
if($getNrow>0)
{
    while($getallnotif=mysqli_fetch_array($getnotifct)){

        $getTypeN=$getallnotif['notiftype'];
        $getUIDN=$getallnotif['uid'];
        $getNudetail=mysqli_query($db,"SELECT * FROM $utable WHERE id='$getUIDN'");
        $getNu=mysqli_fetch_assoc($getNudetail);
         if($getNu['uimg']!=""){ $imgnamee='<img  class="rounded-circle mr-2" width="39" height="39" src="'.$proilelink.$getNu['uimg'].'">'; }else { $imgnamee='<img width="39" height="39" src="'.$imglinks.'">'; }

            ?>
            <?php if($getTypeN=='plike'){ ?>
                <a class="text-dark dropdown-item" href="#">
                <div class="media">
                    <div style="position: relative;"><?php echo $imgnamee; ?><i style="position: absolute;" class="fa fa-heart text-danger mt-4  ml-n4 bg-white"></i></div>
                    
                    <div class="media-body">
                        <p class="py-0 my-0 text-info"><strong>Post Like</strong><span class="ml-2" style="font-size:11px"><?php echo time_ago_in_php($getallnotif['thedate']); ?></span
                        ></p>
                        <p class="py-0 my-0"><i class="fa fa-user-circle mr-2"></i><?php echo $getNu['name']; ?></p>
                        
                    </div>
                    
                </div>
            </a>
            <?php } ?>
            <?php if($getTypeN=='follow'){ ?>
                <a class="text-dark dropdown-item" href="#">
                <div class="media">
                    <div style="position: relative;"><?php echo $imgnamee; ?><i style="position: absolute;" class="fa fa-check-circle text-success mt-4  ml-n4 bg-white"></i></div>
                    
                    <div class="media-body">
                        <p class="py-0 my-0 text-success"><strong>Following You</strong><span class="ml-2" style="font-size:11px"><?php echo time_ago_in_php($getallnotif['thedate']); ?></span
                        ></p>
                        <p class="py-0 my-0"><i class="fa fa-user-circle mr-2"></i><?php echo $getNu['name']; ?></p>
                        
                    </div>
                    
                </div>
            </a>
            <?php } ?>

        <?php 
    }

}else {
    echo 'No notification found';
}

} } ?>