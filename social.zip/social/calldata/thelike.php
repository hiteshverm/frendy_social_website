<?php 
  include"../tempart/connect.php"; 
 include"../tempart/function.php"; 
if(isset($_SESSION['dssion'])) {
    $getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['dssion']."'");
    $getrowsifo=mysqli_num_rows($getinfo);
    if($getrowsifo>0)
    {
        $getarrinfo=mysqli_fetch_assoc($getinfo);
date_default_timezone_set("Asia/Kolkata"); 
$info = getdate();
$dated = $info['mday'];
$monthe = $info['mon'];
$year = $info['year'];
$hour = $info['hours'];
$min = $info['minutes'];
$sec = $info['seconds'];
if($monthe<10)
{
    $month='0'.$monthe;
}else {
    $month=$monthe;
}
if($dated<10)
{
    $date='0'.$dated;
}else 
{
    $date=$dated;
}
if($hour<10){
    $hourr='0'.$hour;
}else {
    $hourr=$hour;
}
if($min<10){
    $minn='0'.$min;
}else {
    $minn=$min;
}
if($sec<10){
    $secc='0'.$sec;
}else {
    $secc=$sec;
}
$thedate=$date.'-'.$month.'-'.$year.' '.$hourr.':'.$minn.':'.$secc;

if(isset($_POST['lunid']))
{
    $lunid=$_POST['lunid'];
    $insetlike=mysqli_query($db,"UPDATE $likepost SET deletation='1' WHERE uid='".$_SESSION['dssion']."' AND postid='$lunid' and deletation='0'");
    if($insetlike)
    {
        
        echo custom_number_format(getLikeDB($db,$lunid,$likepost));
    }else {
        echo 'no';
    }
}
if(isset($_POST['lid']))
{
    $lid=$_POST['lid'];
    $insetlike=mysqli_query($db,"INSERT INTO $likepost SET uid='".$_SESSION['dssion']."',postid='$lid',thedate='$thedate'");
    if($insetlike)
    {
        $getpostudel=mysqli_query($db,"SELECT * FROM $dataposttbl WHERE id='$lid' AND deletation='0'");
        $genotarr=mysqli_fetch_assoc($getpostudel);
        $poids=$genotarr['uid'];

        $insertnotif=mysqli_query($db,"INSERT INTO $notifcenter SET uid='".$_SESSION['dssion']."',postid='$lid', rectid='$poids',notiftype='plike',thedate='$thedate'");
        
         echo custom_number_format(getLikeDB($db,$lid,$likepost));
        
    }else {
        echo 'no';
    }
}

if(isset($_POST['id'])) {
        $id=$_POST['id'];
        
        $insert=mysqli_query($db,"INSERT INTO $sofollow SET myid='".$_SESSION['dssion']."',fid='$id',thedate='$thedate'");
        if($insert){
            $insertnotifs=mysqli_query($db,"INSERT INTO $notifcenter SET uid='".$_SESSION['dssion']."', rectid='$id',notiftype='follow',thedate='$thedate'");
            echo 1;
        }else{
            echo 0;
        }
    }
    if(isset($_POST['nid'])) {
        $Nid=$_POST['nid'];
        $check=mysqli_query($db,"SELECT * FROM $sofollow WHERE  fid='$Nid' and myid='".$_SESSION['dssion']."'");
        $row=mysqli_num_rows($check);
        if($row!=0)
        {
            $fetch=mysqli_fetch_array($check);
            $fid=$fetch['id'];
            $detele_data=mysqli_query($db,"DELETE FROM $sofollow WHERE id='$fid' ");
            if($detele_data){
                echo 1;
            }else{
                echo 0;
            }
        }else{
            echo 0;
        }
    }
}

}
?>