<?php
include"../tempart/connect.php";
if(isset($_POST['temail'])){
	$email=trim($_POST['temail']);
	$password=trim($_POST['pass']);
	$check=mysqli_query($db,"SELECT * FROM users where email='$email' and password='$password'");
	$row=mysqli_num_rows($check);
	if($row!=0){
		$array=mysqli_fetch_array($check);
		if($array['fistverify']!="")
		{
			echo $array['id'];
		}else {
		$_SESSION['dssion']=$array['id'];
		$_SESSION['myname']=$array['name'];
		$updatelive=mysqli_query($db,"UPDATE users SET livestatus='Y' WHERE id='".$array['id']."'");
		echo 's';
	}
	}else{
		echo 'n';
	}
}


?>