<?php 
  include"../tempart/connect.php"; 
 include"../tempart/function.php"; 
if(isset($_SESSION['dssion'])) {
    $getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['dssion']."'");
    $getrowsifo=mysqli_num_rows($getinfo);
    if($getrowsifo>0)
    {
        $getarrinfo=mysqli_fetch_assoc($getinfo);

if(isset($_POST['idp']))
{
    $idp=$_POST['idp'];
    $delqry=mysqli_query($db,"UPDATE datapost SET deletation='1' WHERE uid='".$_SESSION['dssion']."' and id='$idp'");
    if($delqry)
    {
        echo 1;
    }else
    {
        echo 0;
    }
}

}

}
?>