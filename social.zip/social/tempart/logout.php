<?php
include"connect.php";
 if(isset($_SESSION['dssion'])){
    $updatelive=mysqli_query($db,"UPDATE users SET livestatus='N' WHERE id='".$_SESSION['dssion']."'");
 	session_destroy();
 	header("location:../index.php");

 }
?>