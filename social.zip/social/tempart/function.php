<?php
$hostpath="http://localhost/social/";
$hostlink="http://localhost/social/assets/";
$fileset='<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="'.$hostlink.'css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="'.$hostlink.'css/style.css">
	<script src="'.$hostlink.'js/main.js" type="text/javascript"></script>
	<script type="text/javascript" src="'.$hostlink.'js/popper.min.js"></script>
	<script src="'.$hostlink.'js/bootstrap.min.js" type="text/javascript"></script> ';

	$logo='logo4.png';

	//pages
	$index='index.php';
	$logout='logout.php';
	//tables
	$utable='zusers';
	$dataposttbl='zdatapost';
	$likepost='zlikepost';
	$sofollow='zsofollow';
	$chatmsg='zchatmsg';
	$notifcenter='znotifcenter';
	//pages
	$post='post.php';
	$lodpnlrq='loadpnl.php';
	$loadvpnl='loadvpnl.php';
	$fordelpost='delpost.php';
	$thelike='thelike.php';
	$imgpost='withotext.php';
	$txtwithimg='txtwithimg.php';
	$loaddata='loadata.php';
	$fsearch='find.php';
	$finduser='finduser.php';
	$ulist='userlist.php';
	$following='following.php';
	$followers='followers.php';
	$loadtimeline='loadtimeline.php';
	$loadfollowing='loadfollowing.php';
	$loadfollower='loadfollower.php';
	$sender='sender.php';
	$loadmsg='loadmsg.php';
	$sendpopup='sendpopup.php';
	$chatnbr='chatnumber.php';
	$chatlive='chatlive.php';
	$msglists='messagelist.php';
	$messages='messages.php';
	$redmsgnotif='msgnotifread.php';
	$loadnotifct='loadnotification.php';
	$notificatonpg='notification.php';
	$loadnbrnotif='loadnbrnotif.php';
	$sendreadnotif='sendreadnotif.php';
	$calldata='calldata/';
	//folders
	$images='images/';
	$media='media/';
	$proile='profile/';
	$postimg='postimg/';
	$chatbox='chatbox/';
	$tempart='tempart/';
	$imglink=$hostlink.$images;
	$medlink=$hostlink.$media;
	$proilelink=$hostlink.$media.$proile;
	$postlink=$hostlink.$media.$postimg;

	//settings
	$fsetting='settings/';
	$imglinks=$hostlink.$images.'user.png';
	$imgfavico=$hostlink.$images.'favicon.png';
	$mainsetLink=$hostpath.$fsetting.$index;
	$mainlink=$hostpath.$index;
	$postdata=$hostpath.$calldata.$post;
	$getPnltxt=$hostpath.$calldata.$lodpnlrq;
	$getvpnl=$hostpath.$calldata.$loadvpnl;
	$senddel=$hostpath.$calldata.$fordelpost;
	$sentlike=$hostpath.$calldata.$thelike;
	$imgonly=$hostpath.$calldata.$imgpost;
	$withtext=$hostpath.$calldata.$txtwithimg;
	$DISLoadVDLink=$hostpath.$calldata.$loaddata;
	$DISfindLink=$hostpath.$calldata.$fsearch;
	$profilelink=$hostpath.$proile.$index.'?profile=';
	$finulink=$hostpath.$calldata.$finduser;
	$chatUList=$hostpath.$calldata.$ulist;
	$getTimeline=$hostpath.$calldata.$loadtimeline;
	$profileFing=$hostpath.$proile.$following.'?following=';
	$profileFer=$hostpath.$proile.$followers.'?follower=';
	$searchlink=$hostpath.'search.php?s=';
	$getfolling=$hostpath.$calldata.$loadfollowing;
	$getfwr=$hostpath.$calldata.$loadfollower;
	$chatlink=$hostpath.$chatbox.$index.'?chat=';
	$msgsend=$hostpath.$calldata.$sender;
	$allmsg=$hostpath.$calldata.$loadmsg;
	$msgpopup=$hostpath.$calldata.$sendpopup;
	$msgnbr=$hostpath.$calldata.$chatnbr;
	$chatlives=$hostpath.$calldata.$chatlive;
	$logouts=$hostpath.$tempart.$logout;
	$mmlist=$hostpath.$calldata.$msglists;
	$msglista=$hostpath.$chatbox.$messages;
	$mnotifred=$hostpath.$calldata.$redmsgnotif;
	$loadnotification=$hostpath.$calldata.$loadnotifct;
	$notificaton=$hostpath.$chatbox.$notificatonpg;
	$loadnntif=$hostpath.$calldata.$loadnbrnotif;
	$sndrednotif=$hostpath.$calldata.$sendreadnotif;

function time_ago_in_php($timestamp){
  
  date_default_timezone_set("Asia/Kolkata");         
  $time_ago        = strtotime($timestamp);
  $current_time    = time();
  $time_difference = $current_time - $time_ago;
  $seconds         = $time_difference;
  $minutes = round($seconds / 60); // value 60 is seconds  
  $hours   = round($seconds / 3600); //value 3600 is 60 minutes * 60 sec  
  $days    = round($seconds / 86400); //86400 = 24 * 60 * 60;  
  $weeks   = round($seconds / 604800); // 7*24*60*60;  
  $months  = round($seconds / 2629440); //((365+365+365+365+366)/5/12)*24*60*60  
  $years   = round($seconds / 31553280); //(365+365+365+365+366)/5 * 24 * 60 * 60
                
if ($seconds <= 60){ return "Just Now"; } else if ($minutes <= 60){
if ($minutes == 1){ return "one min ago"; } else { return "$minutes min ago"; } } else if ($hours <= 24){ if ($hours == 1){ return "an hour ago"; } else { return "$hours hrs ago"; } } else if ($days <= 7){ if ($days == 1){ return "yesterday"; } else { return "$days days ago"; } } else if ($weeks <= 4.3){ if ($weeks == 1){ return "a week ago"; } else { return "$weeks weeks ago"; } } else if ($months <= 12){ if ($months == 1){ return "a month ago"; } else { return "$months months ago"; } } else { if ($years == 1){ return "one year ago"; } else { return "$years years ago";
} } }

function custom_number_format($n, $precision = 1) {
        if ($n < 900) {
        // Default
         $n_format = number_format($n);
        } else if ($n < 900000) {
        // Thausand
        $n_format = number_format($n / 1000, $precision). 'K';
        } else if ($n < 900000000) {
        // Million
        $n_format = number_format($n / 1000000, $precision). 'M';
        } else if ($n < 900000000000) {
        // Billion
        $n_format = number_format($n / 1000000000, $precision). 'B';
        } else {
        // Trillion
        $n_format = number_format($n / 1000000000000, $precision). 'T';
    }
    return $n_format;
    }
    function getLikeDB($db,$heid,$likepost)
{
$FgetLikes=mysqli_query($db,"SELECT * FROM $likepost WHERE  postid='$heid' and deletation='0'");
$FgetLikerow=mysqli_num_rows($FgetLikes);
return($FgetLikerow);
}

function getFollowers($db,$tb,$uid)
{
	$getFdata=mysqli_query($db,"SELECT * FROM $tb WHERE fid='$uid'");
	$getrowF=mysqli_num_rows($getFdata);
	return($getrowF);
} 
function getFollowing($db,$tb,$uid)
{
	$getFdatag=mysqli_query($db,"SELECT * FROM $tb WHERE myid='$uid'");
	$getrowFg=mysqli_num_rows($getFdatag);
	return($getrowFg);
} 
function getPost($db,$tb,$uid)
{
	$getFpost=mysqli_query($db,"SELECT * FROM $tb WHERE uid='$uid' and deletation='0'");
	$getrowPo=mysqli_num_rows($getFpost);
	return($getrowPo);
} 
 ?>