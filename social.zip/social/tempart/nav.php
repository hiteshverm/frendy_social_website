<header class="hdrbg border-bottom py-2 fixed-top">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-md-2">
					<a href="<?php echo $mainlink; ?>">
					<img width="90" src="<?php echo $hostlink.'images/'.$logo; ?>"></a>
				</div>
				<div class="col-md-6"><div class="searchover">

				<div class="input-group ">
					<input placeholder="Search..." autocomplete="off" type="text" name="search" id="search" class="form-control rounded-pill">
					<button class="btn crdbg finddata">
						<i class="fa fa-search text-white"></i>
					</button>
					

				</div>
				<div class="searchbox shadow"></div>
			</div>
				</div>
				<div class="col-md-4">
					<nav class="ml-auto align-items-center d-flex justify-content-between">
						<a href="<?php echo $mainlink; ?>">
								<span class="fa-stack fa-lg" >
									<i class="fa fa-circle text-dark fa-stack-2x"></i>
									<i class="fa fa-home text text-white fa-stack-1x"></i>
								</span>
							</a>
						
					<div class="dropdown dropleft">
						<span id="sendread" data-toggle="dropdown" class="fa-stack fa-lg loadmsg">
							<i class="fa fa-circle text-dark fa-stack-2x"></i>
							<i class="fa fa-envelope  text-white fa-stack-1x"></i>
						</span>
						<span id="readdata"></span>
						<div class="dropdown-menu col-xs-12 shadow">
							<div class="dropdown-header">Messages</div>
							<span id="msglist"></span>
							<div class="dropdown-divider"></div>
      						<a class="dropdown-item" href="<?php echo $msglista; ?>">View All</a>
						</div>
					</div>	
					<div class="dropdown dropleft">	
						<span id="sendreadn" data-toggle="dropdown" class="fa-stack fa-lg loadnots">
							<i class="fa fa-circle text-dark fa-stack-2x"></i>
							<i class="fa fa-bell text text-white fa-stack-1x"></i>
						</span>
						<span id="readdatan"></span>
						<div class="dropdown-menu col-xs-12 shadow">
							<div class="dropdown-header">Notification</div>
							<span id="notiflist"></span>
							<div class="dropdown-divider"></div>
      						<a class="dropdown-item" href="<?php echo $notificaton; ?>">View All</a>
						</div>
					</div>
						<div class="dropdown dropleft">
							<?php echo $imgnamesec; ?>
						
						<div class="dropdown-menu shadow">
						    <a class="dropdown-item" href="<?php echo $mainsetLink; ?>">Setting</a>
						    <a class="dropdown-item" href="<?php echo $profilelink.$_SESSION['dssion']; ?>">Profile</a>
						    <a class="dropdown-item" href="<?php echo $logouts; ?>">Logout</a>
						</div>

					</div>
					</nav>
						
				</div>
			</div>
		</div>
	</header>
	