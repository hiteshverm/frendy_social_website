<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Frendy Zone</title>
	<link rel="icon" type="image/x-icon" href="<?php echo $imgfavico; ?>">
	 <?php echo $fileset; ?>
	 <script type="text/javascript">
	$(document).ready(function(){
		function myFunction(){
			$('#showlist').load('<?php echo $chatUList; ?>');
		}
		setInterval(function(){
			myFunction();
		},3000);
	});
</script>
<script type="text/javascript">
   	$(document).ready(function(){
   		$(".loadmsg").click(function(){
   			$("#msglist").html('<div class="spinner-border spinner-border-sm mr-2"></div>');
   			var iddss='1';
   			$.ajax({
				url:"<?php echo $mmlist; ?>",
				data:"id="+iddss,
				type:"post",
				success:function(data){
				$("#msglist").html(data);	

				}
				})

   		})
   		$(".loadnots").click(function(){
   			$("#notiflist").html('<div class="spinner-border spinner-border-sm mr-2"></div>');
   			var idss='1';
   			$.ajax({
				url:"<?php echo $loadnotification; ?>",
				data:"id="+idss,
				type:"post",
				success:function(data){
				$("#notiflist").html(data);	

				}
				})

   		})
   	 function loadCount(){
   	 	$('#readdata,#readdata2').load("<?php echo $msgnbr; ?>");
      }
   	 setInterval(function(){
     loadCount();
   	 },1000);
   	 function loadCountt(){
   	 	$('#readdata4').load("<?php echo $chatlives; ?>");
      }
   	 setInterval(function(){
     loadCountt();
   	 },1000);

   	 function loadNotCount(){
   	 	$('#readdatan').load("<?php echo $loadnntif; ?>");
      }
   	 setInterval(function(){
     loadNotCount();
   	 },1000);	
   	});
   </script>
</head>

