<div id="alerttop"> </div>
<script type="text/javascript">
	$(document).ready(function(){
	$("#search").click(function(){
     
$(".searchbox").show();
	});
	$(".searchbox").mouseleave(function(){
     $(".searchbox").hide();
     
	});

$("#search").keyup(function(){
	var search=$("#search").val();
	if(search=="")
	{
		$(".searchbox").empty();
		return false;
	}else {
		$(".searchbox").empty();
		$(".searchbox").html('<span class="spinner-border spinner-border-sm"></span>');
		$.ajax({
			url:"<?php echo $finulink; ?>",
			data:"search="+search,
			type:"POST",
			success:function(data)
			{
				$(".searchbox").empty();
				$(".searchbox").html(data);
			}
		})
	}
})

	});


</script>
<script type="text/javascript">
		$(document).ready(function(){
			$("#sendread").click(function(){
				var idd='one';
				$.ajax({
					url:"<?php echo $mnotifred; ?>",
					type:"post",
					data:"id="+idd,
					success:function(data)
					{

					}
				});
			});
			$("#sendreadn").click(function(){
				var idsd='one';
				
				$.ajax({
					url:"<?php echo $sndrednotif; ?>",
					type:"post",
					data:"id="+idsd,
					success:function(data)
					{

					}
				});
			});
			$(".finddata").click(function(){
				var search=$("#search").val();
				if(search==""){
					return false;
				}else {
					$(".finddata").html('<span class="spinner-border spinner-border-sm"></span>');
					window.location.href="<?php echo $searchlink; ?>"+search;

				}

		});
			$('#search').keypress(function (e) {
 var key = e.which;
 if(key == 13)  // the enter key code
  {
    var search=$("#search").val();
				if(search==""){
					return false;
				}else {
					$(".finddata").html('<span class="spinner-border spinner-border-sm"></span>');
					window.location.href="search.php?s="+search;

				} 
  }
});
		});
	</script>