<?php include"../tempart/connect.php"; ?>
<?php include"../tempart/function.php"; ?>
<?php include"../tempart/header.php"; ?>
<?php if(isset($_SESSION['dssion'])) {
	$getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['dssion']."'");
	$getrowsifo=mysqli_num_rows($getinfo);
	if($getrowsifo>0)
	{
		$getarrinfo=mysqli_fetch_assoc($getinfo);
		if($getarrinfo['uimg']!=""){ $imgname='<img  class="rounded-circle mr-2" width="45" height="45" src="'.$proilelink.$getarrinfo['uimg'].'">'; }else { $imgname='<img width="39" height="39" src="'.$imglinks.'">'; }
		 if($getarrinfo['uimg']!=""){ $imgnamesec='<img data-toggle="dropdown" class="rounded-circle mr-2" width="45" height="45" src="'.$proilelink.$getarrinfo['uimg'].'">'; }else { $imgnamesec='<img data-toggle="dropdown" width="39" height="39" src="'.$imglinks.'">'; }
 ?>
 <body class="primebg">
<?php include"../tempart/nav.php"; ?>


<section class=" pt-3 mt-5">
 	<div class="container">
 		<div class="row justify-content-center align-items-center">

	<?php if(isset($_REQUEST['profile'])){  
			$pid=$_REQUEST['profile'];
			$getPidinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='$pid'");
			$orproile=mysqli_num_rows($getPidinfo);
			if($orproile>0)
			{
			$getPidArr=mysqli_fetch_assoc($getPidinfo);
			if($getPidArr['uimg']!=""){ $imgname='<img  class="mainimgborder margintop " width="39" height="39" src="'.$proilelink.$getPidArr['uimg'].'">'; }else { $imgname='<img  class="mainimgborder margintop " width="39" height="39" src="'.$imglinks.'">'; }

			$unfollow=mysqli_query($db,"SELECT * FROM $sofollow WHERE  fid='".$getPidArr['id']."' and myid='".$_SESSION['dssion']."' ");
                                $row=mysqli_num_rows($unfollow);
	  ?>
 			<div class="col-md-8">
			<div class="card pr cardhight"></div>
			<!----start------>
			<div class="media">
				<?php echo $imgname;?>
				<div class="media-body ">
					<div class="d-flex justify-content-between">
					<div>
						<h4 class="mb-3 ml-2"><?php echo $getPidArr['name']; ?>
					</h4>
					</div>
					<div>
						<?php if($pid!=$_SESSION['dssion'])
                                 {
                                 	if($row>0){ ?>
                                 		
							<button class="followbtn unfollow px-3 mt-1  py-2 rounded-pill" id=" <?php echo $pid; ?>" >following</button>

                            <?php  }else {?>
                            	
                                <button class="followbtn mt-1 following rounded-pill px-3 py-2" id=" <?php echo $pid; ?>" >follow</button>
                           
                          <?php } } ?>
					</div>
					</div>
					<a href="<?php echo $profilelink.$pid; ?>">
					<span class="bg-light border text-dark py-2 px-3 text-center mr-2 "><i class="fa fa-home fa-2x"></i> </span></a>
					<a href="<?php echo $profileFing.$pid; ?>">
					<span class="bg-light border text-dark py-2 px-3 text-center mr-2 ">Following <?php echo custom_number_format(getFollowing($db,$sofollow,$pid)); ?></span></a>
					<a href="<?php echo $profileFer.$pid; ?>">
					<span class="bg-light border text-dark py-2 px-3 text-center ">Followers <?php echo custom_number_format(getFollowers($db,$sofollow,$pid)); ?></span></a>
					<?php if($pid!=$_SESSION['dssion'])
                                 { ?>
					<a href="<?php echo $chatlink.$pid; ?>">
					<span class="bg-light border text-dark py-2 px-3 text-center ">Send Message </span></a><?php } ?>
				</div>
					
				</div>
			

			<!-----data section end---->
		<div class="py-2 mt-3">
			<h5>All Post (<?php echo getPost($db,$dataposttbl,$pid); ?>)</h5>
			<hr/>
		</div>
		
		
		<div class="row" id="load_data"></div>
<div id="load_data_message"></div>  
		</div>
		</div>
		<script type="text/javascript">
$(document).ready(function(){
	var mid='<?php echo $pid; ?>';
var limit = 7;var start = 0;var action = 'no';
function load_country_data(limit, start){
	
$.ajax({
url:"<?php echo $getTimeline; ?>",
method:"POST",
data:{limit:limit, start:start, pid:mid},
cache:false,
success:function(data){$('#load_data').append(data);
if(data == ''){
$('#load_data_message').html("<div class='badge py-2 mt-2 w-100 badge-info'>No Data Found</div>");
     action = 'yes';}else{


$('#load_data_message').html('<div align="center"><div class="loader allheading text-center"><span class="bar"></span><span class="bar"></span><span class="bar"></span> <small>Loading...</small></div></div>');
     action = "no";
 }}});}
if(action == 'no'){
action = 'yes';
load_country_data(limit, start);}
 $(window).scroll(function(){
if($(window).scrollTop() + $(window).height() > $("#load_data").height() && action == 'no'){action = 'yes'; start = start + limit; setTimeout(function(){ load_country_data(limit, start);
}, 2000);}});});
</script>
		<script type="text/javascript">
$(document).ready(function(){   
$('button.followbtn').on('click', function(e){
e.preventDefault();
$button = $(this);
if($button.hasClass('following')){
var fid=$(this).attr('id');

$.ajax({
url:"<?php echo $sentlike; ?>",
type:"POST",
data:"id="+fid,
success:function(msg)

{

if(msg==0){return false;}else{  
$button.removeClass('following');
$button.addClass('unfollow');
$button.text('Following');

}}});
}else {var fid=$(this).attr('id');

$.ajax({ url:"<?php echo $sentlike; ?>",
type:"POST",
data:"nid="+fid,
success:function(msg)
{ 
    if(msg==0){return false;}else{  

$button.removeClass('unfollow');
$button.addClass('following');
$button.text('Follow');

} }});}});});
</script>
	<?php }else {
		echo '<div class="col-md-8"><div class="alert alert-danger">No Profile found</alert></div>';
	} } ?>
	</div>
</div>
</section>
<?php include"../tempart/footer.php"; ?>
 </body>
 <?php } }else {  header("location:../index.php"); }?>