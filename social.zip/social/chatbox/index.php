<?php include"../tempart/connect.php"; ?>
<?php include"../tempart/function.php"; ?>
<?php include"../tempart/header.php"; ?>
<?php if(isset($_SESSION['dssion'])) {
	$getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['dssion']."'");
	$getrowsifo=mysqli_num_rows($getinfo);
	if($getrowsifo>0)
	{
		$getarrinfo=mysqli_fetch_assoc($getinfo);
		if($getarrinfo['uimg']!=""){ $imgname='<img  class="rounded-circle mr-2" width="45" height="45" src="'.$proilelink.$getarrinfo['uimg'].'">'; }else { $imgname='<img width="39" height="39" src="'.$imglinks.'">'; }
		 if($getarrinfo['uimg']!=""){ $imgnamesec='<img data-toggle="dropdown" class="rounded-circle mr-2" width="45" height="45" src="'.$proilelink.$getarrinfo['uimg'].'">'; }else { $imgnamesec='<img data-toggle="dropdown" width="39" height="39" src="'.$imglinks.'">'; }
 ?>
 <body class="primebg">
<?php include"../tempart/nav.php"; ?>


<section class=" pt-3 mt-5">
 	<div class="container">
 		<div class="row ">

	<?php if(isset($_REQUEST['chat'])) { 

		$pid=$_REQUEST['chat']; 
		$getuserdata=mysqli_query($db,"SELECT * FROM $utable WHERE id='$pid'");
 	$datafetch=mysqli_fetch_array($getuserdata);
 	if($datafetch['uimg']!=""){ $imgname='<a href="'.$profilelink.''.$pid.'"><img  class="rounded-circle" width="39" height="39" src="'.$proilelink.$datafetch['uimg'].'"></a>'; }else { $imgname='<a href="'.$profilelink.''.$pid.'"><img width="39" height="39" src="'.$imglinks.'"></a>'; }
		?>
	<div class="col-md-4">
 				<div class="card ">
 					<div class="card-header">Chats(<span class="font-weight-bold text-success">Live</span> <span id="readdata4"></span>)</div>	
 					<div class="card-body" id="showlist">
 						
 					</div>
 				</div>
 				
 			</div>
 	<div class="col-md-8">
 		<input type="hidden" name="userid" id="userid" value="<?php echo $pid; ?>">
 		<div class="card">
		<div class="card-header">
	<?php echo $imgname; ?>
						<a href="<?php echo $profilelink.$pid; ?>"><span class="text-capitalize text-dark"><?php echo $datafetch['name'];  ?></span></a></div>
					<div class="card-body">
						<div class="chatmain" id="loadchat">
							
						</div>
					</div>
					<div class="card-footer">
						<div class="input-group">
							<textarea class="form-control" id="newmsg" name="newmsg"></textarea>
							<button class="btn btn-success sender" id='<?php echo $pid ; ?>'>send</button>
						</div>
					</div></div>
 	</div> 
 	<script type="text/javascript">
$(document).ready(function(){
	setTimeout(function(){
 $("#loadchat").animate({"scrollTop":$('#loadchat')[0].scrollHeight},"slow");
},3000);
$('#newmsg').keypress(function (e) {
 var key = e.which;
 if(key == 13)  // the enter key code
  {
var id=$("#userid").val();
  var newmsg=$('#newmsg').val();
 if (newmsg=="") {
 	return false;
 }else{
 	$('.sender').html('<div class="spinner-border text-white"></div>');
 $.ajax({
 	url:'<?php echo $msgsend; ?>',
 	type:'post',
 	data:'newmsg='+newmsg+'&id='+id,
 	success:function(data){
 	if(data==0){
 		return false;
 	}else{
     $('.sender').html('send');
     $('textarea').val("");
     $("#loadchat").animate({"scrollTop":$('#loadchat')[0].scrollHeight},"slow");
 	}	
 	}
 })	

 }
 
}
});	
 $('.sender').click(function(){
 var id=$(this).attr('id');
  var newmsg=$('#newmsg').val();
 if (newmsg=="") {
 	return false;
 }else{
 	$('.sender').html('<div class="spinner-border text-white"></div>');
 $.ajax({
 	url:'<?php echo $msgsend; ?>',
 	type:'post',
 	data:'newmsg='+newmsg+'&id='+id,
 	success:function(data){
 	if(data==0){
 		return false;
 	}else{
     $('.sender').html('send');
     $('textarea').val("");
     $("#loadchat").animate({"scrollTop":$('#loadchat')[0].scrollHeight},"slow");
 	}	
 	}
 })	

 }
 });
});	
</script>
<script type="text/javascript">
	$(document).ready(function(){
    function chatLoad(){
    var id=$('#userid').val();
$.ajax({
	url:"<?php echo $allmsg; ?>",
	data:"userid="+id,
	type:"post",
	success:function(data){
		$("#loadchat").html(data);
	}
})
    }

    setInterval(function(){
     chatLoad();
    },500);
function sendTop(){
 var ide=$('#userid').val();
 $.ajax({
 	url:"<?php echo $msgpopup; ?>",
 	data:"id="+ide,
 	type:"POST",
 	success:function(respo)
 	{

 		if(respo==1)
 		{
 			
 			var audioElement = document.createElement('audio');
                audioElement.setAttribute('src', 'AnydoPopup.mp3');
                audioElement.setAttribute('autoplay', 'autoplay');
 		$("#loadchat").animate({"scrollTop":$('#loadchat')[0].scrollHeight},"slow");	
 		}
 	}
 })
}
setInterval(function(){
	sendTop();
},1000);
	});
</script>
			<?php } ?>
</div></div></section>
<?php include"../tempart/footer.php"; ?>
 </body>
 <?php } }else {  header("location:../index.php"); }?>