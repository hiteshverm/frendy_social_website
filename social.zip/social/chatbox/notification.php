<?php include"../tempart/connect.php"; ?>
<?php include"../tempart/function.php"; ?>
<?php include"../tempart/header.php"; ?>
<?php if(isset($_SESSION['dssion'])) {
	$getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['dssion']."'");
	$getrowsifo=mysqli_num_rows($getinfo);
	if($getrowsifo>0)
	{
		$getarrinfo=mysqli_fetch_assoc($getinfo);
		if($getarrinfo['uimg']!=""){ $imgname='<img  class="rounded-circle mr-2" width="45" height="45" src="'.$proilelink.$getarrinfo['uimg'].'">'; }else { $imgname='<a href=""><img width="39" height="39" src="'.$imglinks.'"></a>'; }
		 if($getarrinfo['uimg']!=""){ $imgnamesec='<img data-toggle="dropdown" class="rounded-circle mr-2" width="45" height="45" src="'.$proilelink.$getarrinfo['uimg'].'">'; }else { $imgnamesec='<img data-toggle="dropdown" width="39" height="39" src="'.$imglinks.'">'; }
 ?>
 <body class="primebg">
<?php include"../tempart/nav.php"; ?>


<section class=" pt-3 mt-5">
 	<div class="container">
 		<div class="row justify-content-center align-items-center">
 			<div class="col-md-7">
 				<div class="card">
 					<div class="card-header"><i class="fa fa-bell  text-info mr-2"></i>All Notificaton</div>
 					<div class="card-body">
 				<?php
 				
$getnotifct=mysqli_query($db,"SELECT * FROM $notifcenter where rectid='".$_SESSION['dssion']."' order by id desc limit  10");
$getNrow=mysqli_num_rows($getnotifct);
if($getNrow>0)
{
    while($getallnotif=mysqli_fetch_array($getnotifct)){

        $getTypeN=$getallnotif['notiftype'];
        $getUIDN=$getallnotif['uid'];
        $getNudetail=mysqli_query($db,"SELECT * FROM $utable WHERE id='$getUIDN'");
        $getNu=mysqli_fetch_assoc($getNudetail);
         if($getNu['uimg']!=""){ $imgnamee='<img  class="rounded-circle mr-2" width="39" height="39" src="'.$proilelink.$getNu['uimg'].'">'; }else { $imgnamee='<img width="39" height="39" src="'.$imglinks.'">'; }

            ?>
            <?php if($getTypeN=='plike'){ ?>
               
                <div class="media border-bottom py-2">
                    <div style="position: relative;"><?php echo $imgnamee; ?><i style="position: absolute;" class="fa fa-heart text-danger mt-4  ml-n4 bg-white"></i></div>
                    
                    <div class="media-body">
                        <p class="py-0 my-0 text-info"><strong>Post Like</strong><span class="ml-2" style="font-size:11px"><?php echo time_ago_in_php($getallnotif['thedate']); ?></span
                        ></p>
                        <a href="<?php echo $profilelink.$getNu['id']; ?>"><p class="py-0 my-0 text-dark"><i class="fa fa-user-circle mr-2"></i><?php echo $getNu['name']; ?></p></a>
                        
                    </div>
                    
                </div>
            
            <?php } ?>
            <?php if($getTypeN=='follow'){ ?>
                
                <div class="media border-bottom py-2">
                    <div style="position: relative;"><?php echo $imgnamee; ?><i style="position: absolute;" class="fa fa-check-circle text-success mt-4  ml-n4 bg-white"></i></div>
                    
                    <div class="media-body">
                        
                        <a href="<?php echo $profilelink.$getNu['id']; ?>">
                        <p class="py-0 my-0 text-dark"><i class="fa fa-user-circle mr-2"></i><?php echo $getNu['name']; ?><strong class="text-success ml-2">Following You</strong></p></a>
                        <p class="py-0 my-0 text-success"><span class="ml-2" style="font-size:11px"><?php echo time_ago_in_php($getallnotif['thedate']); ?></span
                        ></p>
                    </div>
                    
                </div>
           
            <?php } ?>

        <?php 
    }

}else {
    echo 'No notification found';
}  ?>
 			</div></div></div>
 		</div>
 	</div>
 </section>
<?php include"../tempart/footer.php"; ?>
 </body>
 <?php } }else {  header("location:../index.php"); }?>