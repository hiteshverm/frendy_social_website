<?php include"../tempart/connect.php"; ?>
<?php include"../tempart/function.php"; ?>
<?php include"../tempart/header.php"; ?>
<?php if(isset($_SESSION['dssion'])) {
	$getinfo=mysqli_query($db,"SELECT * FROM $utable WHERE id='".$_SESSION['dssion']."'");
	$getrowsifo=mysqli_num_rows($getinfo);
	if($getrowsifo>0)
	{
		$getarrinfo=mysqli_fetch_assoc($getinfo);
		if($getarrinfo['uimg']!=""){ $imgname='<img  class="rounded-circle mr-2" width="39" height="39" src="'.$proilelink.$getarrinfo['uimg'].'">'; }else { $imgname='<a href=""><img width="39" height="39" src="'.$imglinks.'"></a>'; }
		 if($getarrinfo['uimg']!=""){ $imgnamesec='<img data-toggle="dropdown" class="rounded-circle mr-2" width="39" height="39" src="'.$proilelink.$getarrinfo['uimg'].'">'; }else { $imgnamesec='<img data-toggle="dropdown" width="39" height="39" src="'.$imglinks.'">'; }
 ?>
 <body class="primebg">
<?php include"../tempart/nav.php"; ?>
<section class="mt-5">
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<div class="bg-white py-2 px-2 rounded shadow">
					<h5 class="mt-3">Settings</h5>
				</div>
				<div class="media mt-2 bg-white p-3">
					<div id="preview"><img src="<?php echo $proilelink;?><?php echo $getarrinfo['uimg']; ?>" class="output" id="output"/></div>
					<div class="media-body pl-2">
						<form id="form"  method="post" enctype="multipart/form-data">
							
							<div class="progress my-3">
				              <div id="file-progress-bar" class="progress-bar"></div>
				           </div>
				           <div class="showmsg"></div>
				           <input type="file" id="image" name="image" accept="image/*" onchange="loadFile(event)">
				      		<input type="submit" name="submit" id="but_upload" class="btn btn-success" value="Change">
				      	</form>
					</div>
				</div>
				<ul class="list-group">
					<li class="list-group-item d-flex justify-content-between">
						<p class="text-capitalize"><i class="fa fa-user-circle mr-2"></i><?php echo $getarrinfo['name']; ?></p>
						<button class="btn btn-success">Edit <i class="fa fa-pencil ml-2 text-white"></i></button>
					</li>
					<li class="list-group-item d-flex justify-content-between">
						<p><i class="fa fa-key mr-2"></i>*********</p>
						<button class="btn btn-success">Edit <i class="fa fa-pencil ml-2 text-white"></i></button>
					</li>
				</ul>
			</div>
		</div>
	</div>
</section>
<script type="text/javascript">
$(document).ready(function (e) {
 $("#form").on('submit',(function(e) {

 	var files=$("#image").val();
 if(files=="")
 	{
 		alert("slelct image");
 		return false;
 	}else 
 	{
 		$(".showmsg").html('<div class="spinner-border text-success"></div><span class="text-dark">Please wait...</span>');
  e.preventDefault();
  $.ajax({
  	 xhr: function() {
                var xhr = new window.XMLHttpRequest();         
                xhr.upload.addEventListener("progress", function(element) {
                    if (element.lengthComputable) {
                        var percentComplete = ((element.loaded / element.total) * 100);
                        $("#file-progress-bar").width(percentComplete + '%');
                        $("#file-progress-bar").html(percentComplete+'%');
                    }
                }, false);
                return xhr;
            },
         url: "../calldata/uploadimgt.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   beforeSend: function(){
                $("#file-progress-bar").width('0%');
            },
   success: function(data)
      {

      	$(".showmsg").html(data);
    	$("#image").val("");
    	location.reload();
      },
     error: function(e) 
      {
    $("#err").html(e).fadeIn();
      }          
    });
}
 }));
 
});
</script>	
<script type="text/javascript">
  var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
    output.onload = function() {
      URL.revokeObjectURL(output.src) // free memory
    }
  };
</script>
<?php include"../tempart/footer.php"; ?>
 </body>
 <?php } }else {  header("location:../index.php"); }?>